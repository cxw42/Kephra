package Kephra::App::Panel;
our $VERSION = '0.00';

use strict;
use warnings;

my ($left,$right,$bottom);

sub new {}

1;

=head1 NAME

Kephra::Panel - Manager to all side panels 

=head1 DESCRIPTION


=cut